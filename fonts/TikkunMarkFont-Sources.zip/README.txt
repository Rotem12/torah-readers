Tikkun mark-size font derivatives

Taamey Frank CLM by Yoram Gnat: GPL v2 with the font embedding exception, retained.
Original TrueType and SFD sources, full license and documentation are in upstream/TaameyFrankCLM.zip.
Upstream: https://culmus.sourceforge.io/taamim/TaameyFrankCLM.zip
Noto Serif Hebrew: Copyright 2022 The Noto Project Authors; SIL OFL 1.1, included in wwwroot/fonts/OFL.txt.
Modifications: regular-face instancing, renamed families, independent NIKD and TAAM outline-size axes.
Consonants, horizontal metrics and GPOS attachment anchors are preserved.

Rebuild (tested with fontTools 4.49): install fonttools, then run
python tools/build_tikkun_mark_fonts.py
The exact input fonts and both build scripts are included in their expected directory layout.
The existing study-reader font files are not overwritten.
