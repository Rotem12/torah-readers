"""Build Tikkun's regular faces with independent niqqud/cantillation axes.

Reuses the Torah font builder's attachment anchors and font metadata handling.
The study reader's existing NIKD-only faces are not overwritten.
"""
import copy
from pathlib import Path
import tempfile
import urllib.request
import zipfile

from fontTools.designspaceLib import AxisDescriptor, DesignSpaceDocument, SourceDescriptor
from fontTools.pens.recordingPen import DecomposingRecordingPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables.ttProgram import Program
from fontTools.varLib import build
from fontTools.varLib.instancer import instantiateVariableFont

from build_nikud_axis_fonts import (
    FONT_DIR, NIKUD_CODEPOINTS, complete_metric_fields, glyph_center,
    mark_anchors, rename_family,
)

TAAMIM_CODEPOINTS = {*range(0x0591, 0x05B0), 0x05BD}
FACES = (
    ("TaameyFrankCLM-Medium.ttf", "TikkunTaameyFrank-Marks.ttf", "Tikkun Taamey Frank"),
    ("NotoSerifHebrew.ttf", "TikkunNotoSerifHebrew-Marks.ttf", "Tikkun Noto Serif Hebrew"),
)


def mark_glyphs(font, codepoints):
    result = {name for codepoint, name in font.getBestCmap().items() if codepoint in codepoints}
    # Contextual GSUB lookups can select alternate marks absent from the cmap.
    while True:
        previous = len(result)
        for lookup in font["GSUB"].table.LookupList.Lookup:
            for subtable in lookup.SubTable:
                for source, target in getattr(subtable, "mapping", {}).items():
                    if source in result:
                        outputs = target if isinstance(target, list) else [target]
                        result.update(name for name in outputs if font["hmtx"][name][0] == 0)
                for source, targets in getattr(subtable, "alternates", {}).items():
                    if source in result:
                        result.update(name for name in targets if font["hmtx"][name][0] == 0)
        if len(result) == previous:
            return result


def transform_marks(master, original, names, adjustment):
    anchors = mark_anchors(original)
    glyph_set = original.getGlyphSet()  # Always draw pristine outlines, including at axis zero.
    scale = 1 + adjustment / 100
    for name in sorted(names):
        points = anchors.get(name)
        x, y = (tuple(sum(point[index] for point in points) / len(points) for index in (0, 1))
                if points else glyph_center(original, name))
        recording = DecomposingRecordingPen(glyph_set)
        glyph_set[name].draw(recording)
        pen = TTGlyphPen(glyph_set)
        recording.replay(TransformPen(pen, (scale, 0, 0, scale, x * (1 - scale), y * (1 - scale))))
        glyph = pen.glyph()
        old = original["glyf"][name]
        if not old.isComposite() and hasattr(old, "flags") and len(old.flags) == len(glyph.flags):
            glyph.flags = old.flags[:]
        glyph.program = Program()
        glyph.program.fromBytecode([])
        master["glyf"][name] = glyph


def coordinates(font, name):
    return font["glyf"][name].getCoordinates(font["glyf"])[0]


def verify(path):
    base = instantiateVariableFont(TTFont(path), {"NIKD": 0, "TAAM": 0}, inplace=False)
    cmap = base.getBestCmap()
    for tag, selected, unselected in (("NIKD", NIKUD_CODEPOINTS, TAAMIM_CODEPOINTS),
                                      ("TAAM", TAAMIM_CODEPOINTS, NIKUD_CODEPOINTS)):
        high = instantiateVariableFont(TTFont(path), {"NIKD": 0, "TAAM": 0, tag: 100}, inplace=False)
        assert base["hmtx"].metrics == high["hmtx"].metrics, "Advance widths changed"
        assert mark_anchors(base) == mark_anchors(high), "Attachment anchors changed"
        for codepoint, name in cmap.items():
            if codepoint in selected and base["glyf"][name].numberOfContours:
                assert coordinates(base, name) != coordinates(high, name), f"Unscaled {tag}: {name}"
            if codepoint in unselected or 0x05D0 <= codepoint <= 0x05EA:
                assert coordinates(base, name) == coordinates(high, name), f"Unrelated glyph changed: {name}"


def build_face(source_name, output_name, family):
    original = TTFont(FONT_DIR / source_name)
    if "fvar" in original:
        original = instantiateVariableFont(original, {axis.axisTag: axis.defaultValue for axis in original["fvar"].axes}, inplace=False)
    vowels = mark_glyphs(original, NIKUD_CODEPOINTS)
    accents = mark_glyphs(original, TAAMIM_CODEPOINTS)
    assert not vowels.intersection(accents), "Niqqud and accent glyph sets overlap"
    with tempfile.TemporaryDirectory(prefix="tikkun-mark-font-") as folder:
        design = DesignSpaceDocument()
        for tag, name in (("NIKD", "Nikud Size"), ("TAAM", "Cantillation Size")):
            axis = AxisDescriptor()
            axis.tag, axis.name = tag, name
            axis.minimum = axis.default = 0
            axis.maximum = 100
            design.addAxis(axis)
        for nikud, taamim in ((0, 0), (100, 0), (0, 100), (100, 100)):
            master = copy.deepcopy(original)
            transform_marks(master, original, vowels, nikud)
            transform_marks(master, original, accents, taamim)
            complete_metric_fields(master)
            rename_family(master, family)
            path = Path(folder) / f"{nikud}-{taamim}.ttf"
            master.save(path)
            descriptor = SourceDescriptor()
            descriptor.name, descriptor.path = path.stem, str(path)
            descriptor.familyName, descriptor.styleName = family, "Regular"
            descriptor.location = {"Nikud Size": nikud, "Cantillation Size": taamim}
            design.addSource(descriptor)
        design_path = Path(folder) / "marks.designspace"
        design.write(design_path)
        font, _, _ = build(design_path)
        rename_family(font, family)
        output = FONT_DIR / output_name
        font.save(output)
    verify(output)
    print(f"Built {output_name}: independent NIKD/TAAM axes; consonants, other marks, advances and anchors verified.")


def source_package():
    root = FONT_DIR.parents[1]
    source_url = "https://culmus.sourceforge.io/taamim/TaameyFrankCLM.zip"
    upstream = root / "artifacts" / "tikkun-font-source" / "TaameyFrankCLM.zip"
    upstream.parent.mkdir(parents=True, exist_ok=True)
    if not upstream.exists():
        upstream.write_bytes(urllib.request.urlopen(source_url, timeout=30).read())
    with zipfile.ZipFile(upstream) as archive:
        assert any(name.lower().endswith(".sfd") for name in archive.namelist()), "Upstream font sources missing"
    output = FONT_DIR / "TikkunMarkFont-Sources.zip"
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in [Path(__file__), Path(__file__).with_name("build_nikud_axis_fonts.py"),
                     FONT_DIR / "TaameyFrankCLM-Medium.ttf", FONT_DIR / "NotoSerifHebrew.ttf",
                     FONT_DIR / "OFL.txt", FONT_DIR / "licenses/TaameyFrankCLM-LICENSE.txt"]:
            archive.write(path, path.relative_to(root).as_posix())
        archive.write(upstream, "upstream/TaameyFrankCLM.zip")
        archive.writestr("README.txt", (
            "Tikkun mark-size font derivatives\n\n"
            "Taamey Frank CLM by Yoram Gnat: GPL v2 with the font embedding exception, retained.\n"
            "Original TrueType and SFD sources, full license and documentation are in upstream/TaameyFrankCLM.zip.\n"
            "Upstream: " + source_url + "\n"
            "Noto Serif Hebrew: Copyright 2022 The Noto Project Authors; SIL OFL 1.1, included in wwwroot/fonts/OFL.txt.\n"
            "Modifications: regular-face instancing, renamed families, independent NIKD and TAAM outline-size axes.\n"
            "Consonants, horizontal metrics and GPOS attachment anchors are preserved.\n\n"
            "Rebuild (tested with fontTools 4.49): install fonttools, then run\n"
            "python tools/build_tikkun_mark_fonts.py\n"
            "The exact input fonts and both build scripts are included in their expected directory layout.\n"
            "The existing study-reader font files are not overwritten.\n"
        ))
    print(f"Packaged rebuild sources and font licenses: {output.name}")


if __name__ == "__main__":
    for face in FACES:
        build_face(*face)
    source_package()
