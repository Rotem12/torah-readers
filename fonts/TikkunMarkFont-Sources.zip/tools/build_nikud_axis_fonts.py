#!/usr/bin/env python3
"""Build local Hebrew font derivatives with a custom NIKD variation axis.

The axis grows niqqud outlines around their existing OpenType attachment
anchors, leaving consonants, cantillation, and mark-positioning tables
unchanged. Run from this directory's parent with FontTools installed:

    python tools/build_nikud_axis_fonts.py
"""

from __future__ import annotations

import copy
import itertools
import tempfile
from dataclasses import dataclass
from pathlib import Path

from fontTools.designspaceLib import AxisDescriptor, DesignSpaceDocument, SourceDescriptor
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables.ttProgram import Program
from fontTools.varLib import MVAR_ENTRIES, build
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.recordingPen import DecomposingRecordingPen


FONT_DIR = Path(__file__).resolve().parents[1] / "wwwroot" / "fonts"
MAX_NIKUD_ADJUSTMENT = 100
NIKUD_AXIS_TAG = "NIKD"
NIKUD_AXIS_NAME = "Nikud Size"
NIKUD_CODEPOINTS = {*range(0x05B0, 0x05BD), 0x05BF, 0x05C1, 0x05C2, 0x05C7, 0x05C8}


@dataclass(frozen=True)
class FontFace:
    source: str
    output: str
    family: str


FACES = (
    FontFace("NotoSerifHebrew.ttf", "NotoSerifHebrew-Nikud.ttf", "Torah Reader Noto Serif Hebrew"),
    FontFace("NotoRashiHebrew-Variable.ttf", "NotoRashiHebrew-Nikud.ttf", "Torah Reader Noto Rashi Hebrew"),
    FontFace("Cardo-Regular.ttf", "Cardo-Regular-Nikud.ttf", "Torah Reader Cardo Hebrew"),
    FontFace("NotoSansHebrew.ttf", "NotoSansHebrew-Nikud.ttf", "Torah Reader Noto Sans Hebrew"),
    FontFace("FrankRuhlLibre.ttf", "FrankRuhlLibre-Nikud.ttf", "Torah Reader Frank Ruhl Libre"),
    FontFace("DavidLibre-Regular.ttf", "DavidLibre-Regular-Nikud.ttf", "Torah Reader David Libre"),
    FontFace("DavidLibre-Medium.ttf", "DavidLibre-Medium-Nikud.ttf", "Torah Reader David Libre"),
    FontFace("DavidLibre-Bold.ttf", "DavidLibre-Bold-Nikud.ttf", "Torah Reader David Libre"),
    FontFace("TaameyFrankCLM-Medium.ttf", "TaameyFrankCLM-Medium-Nikud.ttf", "Torah Reader Taamey Frank CLM"),
    FontFace("TaameyFrankCLM-Bold.ttf", "TaameyFrankCLM-Bold-Nikud.ttf", "Torah Reader Taamey Frank CLM"),
    FontFace("ShevaNaFallback.ttf", "ShevaNaFallback-Nikud.ttf", "Torah Reader Hebrew Sheva Fallback"),
)

AXIS_NAMES = {
    "wght": "Weight",
    "wdth": "Width",
    "opsz": "Optical Size",
    "slnt": "Slant",
    "ital": "Italic",
    "GRAD": "Grade",
}


def combining_glyphs(font: TTFont) -> set[str]:
    return {
        glyph_name
        for codepoint, glyph_name in font.getBestCmap().items()
        if codepoint in NIKUD_CODEPOINTS
    }


def mark_anchors(font: TTFont) -> dict[str, list[tuple[int, int]]]:
    result: dict[str, list[tuple[int, int]]] = {}
    for lookup in font["GPOS"].table.LookupList.Lookup:
        for subtable in lookup.SubTable:
            lookup_type = lookup.LookupType
            if lookup_type == 9:
                lookup_type, subtable = subtable.ExtensionLookupType, subtable.ExtSubTable
            if lookup_type in (4, 5):  # Mark-to-base and mark-to-ligature.
                coverage = getattr(subtable, "MarkCoverage", None)
                records = getattr(getattr(subtable, "MarkArray", None), "MarkRecord", [])
            elif lookup_type == 6:  # Mark-to-mark.
                coverage = getattr(subtable, "Mark1Coverage", None)
                records = getattr(getattr(subtable, "Mark1Array", None), "MarkRecord", [])
            else:
                continue
            if coverage is None:
                continue
            for glyph_name, record in zip(coverage.glyphs, records):
                anchor = getattr(record, "MarkAnchor", None)
                if anchor is not None:
                    result.setdefault(glyph_name, []).append((anchor.XCoordinate, anchor.YCoordinate))
    return result


def glyph_center(font: TTFont, glyph_name: str) -> tuple[float, float]:
    glyph = font["glyf"][glyph_name]
    if glyph.isComposite():
        glyph.recalcBounds(font["glyf"])
    return (
        (getattr(glyph, "xMin", 0) + getattr(glyph, "xMax", 0)) / 2,
        (getattr(glyph, "yMin", 0) + getattr(glyph, "yMax", 0)) / 2,
    )


def enlarge_combining_marks(font: TTFont, adjustment_percent: int) -> int:
    glyph_names = combining_glyphs(font)
    anchors = mark_anchors(font)
    scale = 1 + adjustment_percent / 100
    glyph_set = font.getGlyphSet()

    for glyph_name in glyph_names:
        points = anchors.get(glyph_name)
        if points:
            anchor_x = sum(point[0] for point in points) / len(points)
            anchor_y = sum(point[1] for point in points) / len(points)
        else:
            anchor_x, anchor_y = glyph_center(font, glyph_name)

        old_glyph = font["glyf"][glyph_name]
        pen = TTGlyphPen(glyph_set)
        transform = (
            scale,
            0,
            0,
            scale,
            anchor_x * (1 - scale),
            anchor_y * (1 - scale),
        )
        outline_pen = TransformPen(pen, transform)
        old_glyph = font["glyf"][glyph_name]
        if old_glyph.isComposite():
            decomposed = DecomposingRecordingPen(glyph_set)
            glyph_set[glyph_name].draw(decomposed)
            decomposed.replay(outline_pen)
        else:
            glyph_set[glyph_name].draw(outline_pen)
        new_glyph = pen.glyph()
        if (
            not old_glyph.isComposite()
            and hasattr(old_glyph, "flags")
            and hasattr(new_glyph, "flags")
            and len(new_glyph.flags) == len(old_glyph.flags)
        ):
            # Keep TrueType contour flags (including OVERLAP_SIMPLE) identical
            # so variable-font interpolation remains compatible.
            new_glyph.flags = old_glyph.flags[:]
        new_glyph.program = Program()
        new_glyph.program.fromBytecode([])
        font["glyf"][glyph_name] = new_glyph
    return len(glyph_names)


def complete_metric_fields(font: TTFont) -> None:
    for table_tag, field_name in MVAR_ENTRIES.values():
        if table_tag not in font or hasattr(font[table_tag], field_name):
            continue
        setattr(font[table_tag], field_name, 0)
        if table_tag == "OS/2":
            # Older static faces omit these optional MVAR metrics. A zero
            # value retains their previous behavior while making the fields
            # explicit for FontTools' variable-font builder.
            font[table_tag].version = max(font[table_tag].version, 2)
    if "OS/2" in font and font["OS/2"].version >= 2:
        for field_name in (
            "ulCodePageRange1",
            "ulCodePageRange2",
            "sxHeight",
            "sCapHeight",
            "usDefaultChar",
            "usBreakChar",
            "usMaxContext",
        ):
            if not hasattr(font["OS/2"], field_name):
                setattr(font["OS/2"], field_name, 0)


def rename_family(font: TTFont, family: str) -> None:
    postscript = "".join(character for character in family if character.isalnum()) + "-Regular"
    values = {
        1: family,
        2: "Regular",
        3: family + " NIKD-axis derivative",
        4: family + " Regular",
        6: postscript,
        16: family,
        17: "Regular",
        18: family + " Regular",
        21: family,
        22: "Regular",
    }
    name_table = font["name"]
    present_ids = {record.nameID for record in name_table.names}
    for name_id, value in values.items():
        if name_id not in present_ids:
            name_table.setName(value, name_id, 3, 1, 0x0409)
            continue
        for record in name_table.names:
            if record.nameID == name_id:
                record.string = value.encode(record.getEncoding())


def source_locations(font: TTFont) -> tuple[list[AxisDescriptor], list[dict[str, float]]]:
    descriptors: list[AxisDescriptor] = []
    tags: list[str] = []
    values: list[list[float]] = []
    for axis in getattr(font.get("fvar"), "axes", []):
        name = AXIS_NAMES.get(axis.axisTag, f"Axis {axis.axisTag}")
        descriptor = AxisDescriptor()
        descriptor.name = name
        descriptor.tag = axis.axisTag
        descriptor.minimum = axis.minValue
        descriptor.default = axis.defaultValue
        descriptor.maximum = axis.maxValue
        descriptors.append(descriptor)
        tags.append(axis.axisTag)
        values.append(sorted({axis.minValue, axis.defaultValue, axis.maxValue}))

    locations = [dict(zip(tags, combination)) for combination in itertools.product(*values)] if values else [{}]
    return descriptors, locations


def build_face(spec: FontFace) -> tuple[Path, int]:
    source_path = FONT_DIR / spec.source
    output_path = FONT_DIR / spec.output
    source_font = TTFont(source_path)
    original_axes, locations = source_locations(source_font)
    axes = [*original_axes]
    nikud_axis = AxisDescriptor()
    nikud_axis.name = NIKUD_AXIS_NAME
    nikud_axis.tag = NIKUD_AXIS_TAG
    nikud_axis.minimum = 0
    nikud_axis.default = 0
    nikud_axis.maximum = MAX_NIKUD_ADJUSTMENT
    axes.append(nikud_axis)
    mark_count = len(combining_glyphs(source_font))
    if mark_count == 0:
        raise ValueError(f"{spec.source} has no Hebrew combining marks to scale")

    with tempfile.TemporaryDirectory(prefix="torah-nikud-font-") as temp_name:
        temp_dir = Path(temp_name)
        designspace = DesignSpaceDocument()
        for axis in axes:
            designspace.addAxis(axis)

        for location_index, location in enumerate(locations):
            if original_axes:
                base = instantiateVariableFont(TTFont(source_path), location, inplace=False)
            else:
                base = TTFont(source_path)
            for adjustment in (0, MAX_NIKUD_ADJUSTMENT):
                master = base if adjustment == 0 else copy.deepcopy(base)
                enlarge_combining_marks(master, adjustment)
                complete_metric_fields(master)
                rename_family(master, spec.family)
                master_path = temp_dir / f"master-{location_index}-{adjustment}.ttf"
                master.save(master_path)

                source = SourceDescriptor()
                source.name = f"master-{location_index}-{adjustment}"
                source.path = str(master_path)
                source.familyName = spec.family
                source.styleName = "Regular"
                source.location = {
                    **{axis.name: location[axis.tag] for axis in original_axes},
                    NIKUD_AXIS_NAME: adjustment,
                }
                designspace.addSource(source)

        designspace_path = temp_dir / "nikud.designspace"
        designspace.write(designspace_path)
        variable_font, _, _ = build(designspace_path)
        rename_family(variable_font, spec.family)
        variable_font.save(output_path)

    verify_face(output_path)
    return output_path, mark_count


def verify_face(path: Path) -> None:
    font = TTFont(path)
    axes = {axis.axisTag: axis for axis in font["fvar"].axes}
    if NIKUD_AXIS_TAG not in axes:
        raise ValueError(f"{path.name} has no {NIKUD_AXIS_TAG} axis")
    low = instantiateVariableFont(TTFont(path), {NIKUD_AXIS_TAG: 0}, inplace=False)
    high = instantiateVariableFont(TTFont(path), {NIKUD_AXIS_TAG: MAX_NIKUD_ADJUSTMENT}, inplace=False)
    mark_names = combining_glyphs(low)
    changed = [name for name in mark_names if low["glyf"][name].getCoordinates(low["glyf"])[0] != high["glyf"][name].getCoordinates(high["glyf"])[0]]
    unchanged = sorted(mark_names - set(changed))
    if unchanged:
        raise ValueError(f"{path.name} leaves combining marks unscaled: {', '.join(unchanged)}")
    letter_names = {
        glyph_name
        for codepoint, glyph_name in low.getBestCmap().items()
        if 0x05D0 <= codepoint <= 0x05F2
    }
    changed_letters = [
        name
        for name in letter_names
        if low["glyf"][name].getCoordinates(low["glyf"])[0]
        != high["glyf"][name].getCoordinates(high["glyf"])[0]
    ]
    if changed_letters:
        raise ValueError(f"{path.name} changes Hebrew letters: {', '.join(changed_letters)}")
    if mark_anchors(low) != mark_anchors(high):
        raise ValueError(f"{path.name} changes mark attachment anchors with NIKD")


def main() -> None:
    for spec in FACES:
        path, count = build_face(spec)
        print(f"Built {path.name}: NIKD 0–{MAX_NIKUD_ADJUSTMENT}, {count} niqqud glyphs; letters and anchors verified unchanged")


if __name__ == "__main__":
    main()
