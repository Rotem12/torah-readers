self.assetsManifest = {
  "version": "G/JnTSvp",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-LzuyfCqmuZrjrA1a4NaaqxbFja8si6eQ0RpfbZofaAI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.105inx8v2w.wasm"
    },
    {
      "hash": "sha256-k9HV/Po3Ge7/Bnk1xtG/yrXhap2htcHgda3k7LaP0mY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.dw23t4by8t.wasm"
    },
    {
      "hash": "sha256-8/WcnMTxxKfwDnfEOcJyot0utjsomnzC8+QdjNj1Y/k=",
      "url": "_framework/Microsoft.AspNetCore.Components.l2j2h7hssq.wasm"
    },
    {
      "hash": "sha256-oDcpyYbqdkq6hP6NijTRWyXx2c2DKL6qilKSIzNmK3I=",
      "url": "_framework/Microsoft.Extensions.Configuration.47mkb8d5uo.wasm"
    },
    {
      "hash": "sha256-ZMSiWFGZbJVZPj28eku0yZNbnGhFfzFj6gpep+3y9tw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.488ris6j7m.wasm"
    },
    {
      "hash": "sha256-o5L9N1UOhqfOacmjcz9QfaqDLjHJf5HS/F+zQk1y9Ko=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.tsl8t8fg2u.wasm"
    },
    {
      "hash": "sha256-4yVeg91zDUgMM4sIQMsIH4OUC/bXDmWdUtApO2F3H78=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.73vamhb47q.wasm"
    },
    {
      "hash": "sha256-HA794oey9tnbxPmEPxnLeVpNnd9Ez3NCmXHHuP961+Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.cum1owb24o.wasm"
    },
    {
      "hash": "sha256-OcjvqavRSEq7aLkkfXs7LhJHQ0QKjilkSs0cgjJEgx0=",
      "url": "_framework/Microsoft.Extensions.Logging.3lly2ppfku.wasm"
    },
    {
      "hash": "sha256-2t4TAQn0xokJ7Mco2BIHVVdMkAEiTDaDy5A7QGFwuS8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.mpsq3iit8w.wasm"
    },
    {
      "hash": "sha256-Cb23UqG7cGF5BQcY7t9uQF93CxmshSCFl7gYh338cN8=",
      "url": "_framework/Microsoft.Extensions.Options.1y8ng0246k.wasm"
    },
    {
      "hash": "sha256-HJCRf47TZxDGpqSupFubM3cMlAW5vgUSpfvGnKaJeXA=",
      "url": "_framework/Microsoft.Extensions.Primitives.cey721uwr9.wasm"
    },
    {
      "hash": "sha256-tWu37j/RoE6Pwu6s46idTVIaPuEWCkAbsWSyzgKFWXI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.vjcfjtelwd.wasm"
    },
    {
      "hash": "sha256-f6IMbC15tEqDP+U4rrb4Y1TSPDcWvSJUiCpQjuwjB3Q=",
      "url": "_framework/Microsoft.JSInterop.puj8ve9xsd.wasm"
    },
    {
      "hash": "sha256-cCj4alGzkf0o515IdjuWPK2cQHdW8faacLWIeiyZh6E=",
      "url": "_framework/System.Collections.Concurrent.g0257qsjg2.wasm"
    },
    {
      "hash": "sha256-cyBEep4dTkjJYdbQZ+YL3iGmYCQS7ROFuQ5II+ox1M8=",
      "url": "_framework/System.Collections.Immutable.h7o8bed4ie.wasm"
    },
    {
      "hash": "sha256-uL5feht++rOlXzA1nR9j14dwU7rsE1YlePYalSjcYPQ=",
      "url": "_framework/System.Collections.s30n5futfc.wasm"
    },
    {
      "hash": "sha256-rmHX/vP8IHgIBRQl6c1mYGutMGDOL9irayG03Yuadg8=",
      "url": "_framework/System.ComponentModel.iv4cyr9ulo.wasm"
    },
    {
      "hash": "sha256-vKSPtHL9RWsyKZk5AEk+20dxOnKYoDEDrMH2wR0vPVM=",
      "url": "_framework/System.Console.wrlezzx7ro.wasm"
    },
    {
      "hash": "sha256-SKuGcoXXouqFsH1hHB2JHlKJ7K+ieY5xTiD8PAgj2G8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.4pjkc26ecl.wasm"
    },
    {
      "hash": "sha256-fZpB2NFmoDJXAqnCYU4+XAKkZbE51ViM3KsQ+bxqVOo=",
      "url": "_framework/System.IO.Pipelines.px0vglstfo.wasm"
    },
    {
      "hash": "sha256-dpdyha0byapx8dudWgaNSgor+nZTw7rvSKxtI3Kg/a8=",
      "url": "_framework/System.Linq.u6kdo6oayy.wasm"
    },
    {
      "hash": "sha256-m0n7rRLsNRQhBinfK5Uxk3QHKSyUTL0ve+kF8ICrN5c=",
      "url": "_framework/System.Memory.j2wxtriqj6.wasm"
    },
    {
      "hash": "sha256-wwdDLJ3Ft/Fp2U7CgFpH+Am2HXBHtk/5IZrkjE0psYM=",
      "url": "_framework/System.Net.Http.z496gtrlqt.wasm"
    },
    {
      "hash": "sha256-kAYw5gOPxDmbJc5mwBwvRZ5WPH3uUyrEgDjsUuo0a1M=",
      "url": "_framework/System.Net.Primitives.c5r0ouu56u.wasm"
    },
    {
      "hash": "sha256-TCgHH3CtRxXdu0Z/rUlJ1t6E/eXn0CY6CQ+WpYif80c=",
      "url": "_framework/System.Net.Requests.wlejzt7go8.wasm"
    },
    {
      "hash": "sha256-yjrpUsVdIXSuNxUygxr1Q1Z1ASE2DcFhaYCsxG8Ohhw=",
      "url": "_framework/System.ObjectModel.aj4d5ys7y6.wasm"
    },
    {
      "hash": "sha256-1SJj749qduGGqGiybEiqAyrP8JjnIntngDDKVcf40X4=",
      "url": "_framework/System.Private.CoreLib.vbktth7h00.wasm"
    },
    {
      "hash": "sha256-9ZMHn7Toz62wlLZPqashUwd0SGov/s5I+0wWXAxacUY=",
      "url": "_framework/System.Private.Uri.bk34xc5z6l.wasm"
    },
    {
      "hash": "sha256-subN4GeRX41RGMetqHoww+/Yr+o/uCpaS9oTrMeKJr0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ae3uao1vst.wasm"
    },
    {
      "hash": "sha256-jDDKnyVwYqWZbs59vfl1nmjQPfgyIPMTtJfRhTwefY4=",
      "url": "_framework/System.Runtime.orpc2gkcbn.wasm"
    },
    {
      "hash": "sha256-cTpFIxaNUWLXKQa2yGmNxTQNwgdyj7W4RAOSXRdsk50=",
      "url": "_framework/System.Security.Cryptography.r9ft3wvid9.wasm"
    },
    {
      "hash": "sha256-VweqWyrJeNmytU5EybIHgqX8R8/l8RAlEQnRaK2uSr0=",
      "url": "_framework/System.Text.Encodings.Web.poz8e5l19c.wasm"
    },
    {
      "hash": "sha256-g+bKYRxvV2R/0DxSWRzGx7Z3roadmCsdoZubKMmvsEw=",
      "url": "_framework/System.Text.Json.3o6nl4iyq2.wasm"
    },
    {
      "hash": "sha256-juczTXHqaZE8ZONMSuTGMsZe3v4BeRTUyXBH5un1+eQ=",
      "url": "_framework/System.Text.RegularExpressions.6qyveeytw9.wasm"
    },
    {
      "hash": "sha256-kBfR7mRpfLrW2joaE9u4vw4dprYTe+RXlogeoXx9idg=",
      "url": "_framework/System.Threading.8ak7qnz1xz.wasm"
    },
    {
      "hash": "sha256-Bpc0bT4pOUT5Q09+dX8s0tAUA78qZpsmV5RwsAAOH78=",
      "url": "_framework/TorahReaders.Core.asggch0l85.wasm"
    },
    {
      "hash": "sha256-IacVOu18olOmVTowWnQKxD8JuTJnkq2+ENBC71PI3Yo=",
      "url": "_framework/TorahReaders.Web.f4kco01t2r.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-EygPNDitdY5PKLQsrNrFGlajWIt3IZ9hii9ObIh9QVw=",
      "url": "_framework/dotnet.3k0pl1wyig.js"
    },
    {
      "hash": "sha256-jZddobLBM2C3lQhYQ61xSQJ/WqD3eQCO3RzoHGaOjx0=",
      "url": "_framework/dotnet.native.b6l13xorvf.js"
    },
    {
      "hash": "sha256-JTxXd17wbrHKV/375moHFUFc3a/ofVTPPqSTk6KwNj0=",
      "url": "_framework/dotnet.native.rw4kynp763.wasm"
    },
    {
      "hash": "sha256-QbnqrZGHtGq7wudS17/AYEPpH9JkphrsyVllD6JHmds=",
      "url": "_framework/dotnet.runtime.v06hirbjsv.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-thjwxulTavEg8Un9TWQB2QmVi6I59eS6T3pPaKzVYe8=",
      "url": "book.svg"
    },
    {
      "hash": "sha256-5WQgYNqEQuw2m1NQRIdfElsG2DsbupVd9moW9jLcqAo=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-iS2iCB61fcq5S4dmcJR+pzOTiTdWitSSUTfhVxTfByA=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-k8rvkhNgeI3DsOMhNrsm8WvFdxfsSC1I/H/UOCBhcWU=",
      "url": "fonts/NotoSerifHebrew.ttf"
    },
    {
      "hash": "sha256-m5/gKLW6dNIxZZobuvDtCbEedZ0cpqBwmZ4W0VFha0c=",
      "url": "fonts/OFL.txt"
    },
    {
      "hash": "sha256-QSoo20UkcBubMQnS6HChiiu6TOyqeUquxdLOnKNoBC8=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-DBIXecO9Jg1d4Dm3AFkw75Rgsth+qXkIOqkaRAM7KNE=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-7pv+5/vq3H599DlDagSiPAfIhQeXaU12UUOfoA/aeRA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-jrrhrbfG9eHJN4F3vuPtIGW0hepNG0J8X/5H+jfFTJI=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-UIn/P6RsGRsSrU7z2nIWTLpPpmDgTvQGfm/yvxMEZT4=",
      "url": "nikud.mjs"
    },
    {
      "hash": "sha256-3fdi0b0TXxziHIR5rCxwmWTn2whnInJOzSrtUXblk/I=",
      "url": "reader-browser.js"
    },
    {
      "hash": "sha256-Cvtb+KctPM/1BH2yHzku/BoAwgn6HFlgJgdiBFgLhcQ=",
      "url": "vendor/README.md"
    },
    {
      "hash": "sha256-svbZST63vMX12EIzeGFdQ0ijq5nYIuE5lvP0dLbAS7g=",
      "url": "vendor/havarotjs-0.25.5.mjs"
    },
    {
      "hash": "sha256-S8iApwbPec9cK7Coh8EIcqbNxoUnxNDkC68gA8aCkDQ=",
      "url": "vendor/havarotjs-LICENSE.txt"
    }
  ]
};
