// Checkpoints are small and synchronous; text snapshots use bounded IndexedDB.
(() => {
  const prefix = "torah-reader-spot-v1|";
  const ttl = 24 * 60 * 60 * 1000;
  const maxRecordBytes = 4 * 1024 * 1024;
  const maxTorahPageBytes = 8 * 1024 * 1024;
  const maxTotalBytes = 32 * 1024 * 1024;
  const compactKinds = new Set(["page", "notes", "source"]);
  let dbPromise, currentSpot = null, scrollTimer, restoring = false;
  const studyDialogFocus = new WeakMap();
  function focusableWithin(root) {
    return [...root.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')]
      .filter(element => !element.hidden && element.getAttribute('aria-hidden') !== 'true' &&
        getComputedStyle(element).visibility !== 'hidden' && element.getClientRects().length > 0);
  }
  function openDb() {
    if (!dbPromise) dbPromise = new Promise(resolve => {
      if (!window.indexedDB) { resolve(null); return; }
      const request = indexedDB.open("torah-readers-v1", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("entries", {keyPath:"id"});
      request.onsuccess = () => { request.result.onversionchange = () => request.result.close(); resolve(request.result); };
      request.onerror = request.onblocked = () => resolve(null);
    });
    return dbPromise;
  }
  const requestValue = request => new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  function viewport() {
    const top = document.querySelector(".reader-toolbar")?.getBoundingClientRect().bottom || 0;
    const rows = [...document.querySelectorAll(".passage[data-reference]")];
    const row = rows.find(element => element.getBoundingClientRect().bottom > top + 2);
    return row ? {Reference:row.dataset.reference, Start:Number(row.dataset.start),
      Offset:Math.round((row.getBoundingClientRect().top - top) * 100)/100} : null;
  }
  function saveViewport() {
    if (!currentSpot || restoring) return;
    const view = viewport();
    if (view) {
      currentSpot.SourceReference = view.Reference;
      currentSpot.SourceStart = view.Start;
      currentSpot.Offset = view.Offset;
      try { localStorage.setItem(prefix + currentSpot.Reader, JSON.stringify(currentSpot)); } catch { }
    }
  }
  window.addEventListener("scroll", () => {
    clearTimeout(scrollTimer); scrollTimer = setTimeout(saveViewport, 250);
  }, {passive:true});
  window.addEventListener("pagehide", saveViewport);
  document.addEventListener("visibilitychange", () => { if (document.hidden) saveViewport(); });
  document.addEventListener("copy", event => {
    const selection = document.getSelection();
    const anchor = selection?.anchorNode;
    const element = anchor?.nodeType === Node.ELEMENT_NODE ? anchor : anchor?.parentElement;
    if (!element?.closest?.('.reader[data-reader="torah"]')) return;
    const text = selection?.toString() ?? "";
    if (!text.includes("\u05C8") || !event.clipboardData) return;
    event.clipboardData.setData("text/plain", text.replace(/\u05C8/gu, "\u05B0"));
    event.preventDefault();
  });
  window.readerBrowser = {
    readBookmarks(reader, backup) {
      return localStorage.getItem('torah-reader-bookmarks-v1|' + reader + (backup ? '|backup' : ''));
    },
    writeBookmarks(reader, json, previous) {
      try {
        const key = 'torah-reader-bookmarks-v1|' + reader;
        localStorage.setItem(key + '|backup', previous);
        localStorage.setItem(key, json);
        return true;
      } catch { return false; }
    },
    visibleText() {
      return [...document.querySelectorAll('.passage[data-reference]')].map(row => ({
        key:row.dataset.key, reference:row.dataset.reference, start:Number(row.dataset.start),
        text:[...row.querySelectorAll('.reader-text,.translation')].filter(text => !text.closest('[hidden]')).map(text => text.textContent.replace(/\u05C8/gu, "\u05B0")).join('\n')
      }));
    },
    blurSearch() { document.querySelector('.reader-search input')?.blur(); },
    readSpot(reader) {
      try { return localStorage.getItem(prefix + reader); } catch { return null; }
    },
    saveSpot(reader, json) {
      try {
        const spot = JSON.parse(json);
        localStorage.setItem(prefix + reader, json); currentSpot = spot; return true;
      } catch { return false; }
    },
    stopCheckpoint() { saveViewport(); currentSpot = null; },
    viewport,
    scrollToMarker(id) {
      const row = document.getElementById(id);
      if (!row) return false;
      const top = document.querySelector(".reader-toolbar")?.getBoundingClientRect().bottom || 0;
      window.scrollTo({top:window.scrollY + row.getBoundingClientRect().top - top - 8, behavior:"smooth"});
      return true;
    },
    async restoreAnchor(reference, start, offset) {
      restoring = true;
      try {
        await document.fonts.ready;
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        const candidates = [...document.querySelectorAll(".passage[data-reference]")]
          .filter(row => row.dataset.reference === reference);
        const row = candidates.filter(row => Number(row.dataset.start) <= start).at(-1) || candidates[0];
        if (row) {
          const top = document.querySelector(".reader-toolbar")?.getBoundingClientRect().bottom || 0;
          window.scrollTo(0, window.scrollY + row.getBoundingClientRect().top - top - offset);
        }
      } finally { restoring = false; }
    },
    async readCache(reader, key) {
      try {
        const db = await openDb(); if (!db) return null;
        const entry = await requestValue(db.transaction("entries").objectStore("entries").get(reader + "|" + key));
        if (!entry || entry.expires <= Date.now()) return null;
        // Older .NET snapshots escape every Hebrew letter as six ASCII
        // characters. Normalize in the browser before sending them to WASM.
        return !entry.compact && compactKinds.has(entry.kind)
          ? JSON.stringify(JSON.parse(entry.json)) : entry.json;
      } catch { return null; }
    },
    async writeCache(reader, key, json) {
      try {
        const kind = key.split("|")[0];
        const compact = compactKinds.has(kind);
        if (compact) json = JSON.stringify(JSON.parse(json));
        const bytes = new TextEncoder().encode(json).length;
        const recordLimit = reader === "torah" && kind === "page" ? maxTorahPageBytes : maxRecordBytes;
        if (bytes > recordLimit) return true; // Oversize content remains readable online.
        const db = await openDb(); if (!db) return false;
        const id = reader + "|" + key, now = Date.now();
        const capacity = kind === "page" ? 8 : 12;
        return await new Promise(resolve => {
          // Inspect and prune under the same write lock. Concurrent chapter
          // writes must count each other's entries and preserve the budget.
          const tx = db.transaction("entries", "readwrite"), store = tx.objectStore("entries");
          const request = store.getAll();
          request.onsuccess = () => {
            const all = request.result;
            const alive = all.filter(item => item.id !== id && item.expires > now).sort((a,b) => b.created-a.created);
            const keep = new Set(); let total = bytes, siblings = 0;
            for (const entry of alive) {
              const sibling = entry.reader === reader && entry.kind === kind;
              if ((sibling && ++siblings >= capacity) || total + entry.bytes > maxTotalBytes) continue;
              keep.add(entry.id); total += entry.bytes;
            }
            for (const entry of all) if (!keep.has(entry.id)) store.delete(entry.id);
            store.put({id, reader, kind, json, bytes, compact, created:now, expires:now+ttl});
          };
          tx.oncomplete = () => resolve(true);
          tx.onerror = tx.onabort = () => resolve(false);
        });
      } catch { return false; }
    },
    async nikudMarks(text) {
      const nikud = await import("./nikud.mjs");
      return nikud.marks(text);
    },
    async copy(text) {
      try { await navigator.clipboard.writeText(text); return true; } catch { return false; }
    },
    activateStudyDialog(dialog) {
      if (!dialog || studyDialogFocus.has(dialog)) return;
      const previous = document.activeElement;
      const onKeyDown = event => {
        if (event.key !== 'Tab') return;
        const items = focusableWithin(dialog);
        if (items.length === 0) { event.preventDefault(); dialog.focus(); return; }
        const first = items[0], last = items[items.length - 1], active = document.activeElement;
        if (event.shiftKey && (active === first || !dialog.contains(active))) {
          event.preventDefault(); last.focus();
        } else if (!event.shiftKey && (active === last || !dialog.contains(active))) {
          event.preventDefault(); first.focus();
        }
      };
      dialog.addEventListener('keydown', onKeyDown);
      studyDialogFocus.set(dialog, { previous, onKeyDown });
      (dialog.querySelector('.dialog-close') || focusableWithin(dialog)[0] || dialog).focus({ preventScroll: true });
    },
    maintainStudyDialogFocus(dialog) {
      if (!dialog || !studyDialogFocus.has(dialog) || dialog.contains(document.activeElement)) return;
      (dialog.querySelector('.dialog-close') || focusableWithin(dialog)[0] || dialog).focus({ preventScroll: true });
    },
    deactivateStudyDialog(dialog) {
      const state = dialog && studyDialogFocus.get(dialog);
      if (!state) return;
      dialog.removeEventListener('keydown', state.onKeyDown);
      studyDialogFocus.delete(dialog);
      if (state.previous?.isConnected) state.previous.focus({ preventScroll: true });
    }
  };
})();
